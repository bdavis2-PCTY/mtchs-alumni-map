<html>
<head>
<!-- jQuery -->
<script src="../asset/jquery-3.2.0.js" type="text/javascript"></script>
<script src="http://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.2/modernizr.js"></script>



<!-- Bootstrap -->
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-	BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

<!-- Materialize -->
<!--<script src="../asset/materialize/materialize.min.js" type="text/javascript"></script>
	<link rel="stylesheet" href="../asset/materialize/materialize.min.css" type="text/css" />-->

<script src="../asset/jquery.bootgrid.min.js"></script>
<script src="../asset/jquery.bootgrid.fa.min.js"></script>
<link rel="stylesheet" href="../asset/jquery.bootgrid.min.css">

<title>MTCHS Graduate Map | Admin</title>
<style>
	.row {
	margin:0px;
	}
}
	</style>
</head>
<body>
    <div class="row">
        <div class="col-md-8 col-md-offset-1">
            <h3>To Use: </h3>Upload a CSV or TXT (still comma delimitted) file with columsn of Name, Grad year, Location (currently the number), Education, Job, Salary, and Verified state in that order. Do not include column headers. Upload the file and when ready, click import. Any rows that did not insert will be highlighted <span class="text-danger">Red</span>.</div>
    </div><br>
<div class="row">
<div class="col-md-10 col-md-offset-1">
<form enctype="multipart/form-data" id="form">
    <label for="fileToUpload">Select file to upload:</label>
    <input type="file" style="display:inline" name="fileToUpload" id="fileToUpload">
    <button type="submit" class="btn btn-primary" name="submit" id="uploadButton">Upload</button>
</form>
<div id="result"></div>
</div>
</div>

</body>
<script>
$("#form").submit(function(e) {
    e.preventDefault();
    var formData = new FormData();
formData.append('file', $('#fileToUpload')[0].files[0]);

$.ajax({
       url : 'http://coltonh.smtchs.org/alumni/admin/uploadHandler.php',
       type : 'POST',
       data : formData,
       processData: false,  // tell jQuery not to process the data
       contentType: false,  // tell jQuery not to set contentType
       success : function(data) {
           $("#result").html(data);
       }
});
});
    function uploadUsers() {
         var formData = new FormData();
formData.append('file', $('#fileToUpload')[0].files[0]);
formData.append('finalUpload', 'true');

$.ajax({
       url : 'http://coltonh.smtchs.org/alumni/admin/uploadHandler.php',
       type : 'POST',
       data : formData,
       dataType: 'JSON',
       processData: false,  // tell jQuery not to process the data
       contentType: false,  // tell jQuery not to set contentType
       success : function(data) {
           $("#rows").text(data.result);
           for(var i=0;i<data.errored.length; i++) {
               var id = "tr[data-row-id="+data.errored[i]+"]";
               $(id).css("background-color", "#f2dede");
           }
       }
});
        
    }
    $("#uploadButton").click(function() {
        
    });
    function numberWithCommas(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}
</script>
</html>

